package com;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String s="";
		System.out.println(s.split(",").length);*/
		System.out.println((int)(char)(byte)-2);
		System.out.println((float)(int)(char)(-2));
		System.out.println((char)(2));
		System.out.println((int)(char)(-2));
	}

}
