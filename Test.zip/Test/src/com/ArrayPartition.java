package com;

import java.util.Vector;

public class ArrayPartition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a={1,0,1,7,2,4};
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			sum+=a[i];
		}
		Vector<Vector<Integer>> v1=new Vector<Vector<Integer>>();
		
	}

}
